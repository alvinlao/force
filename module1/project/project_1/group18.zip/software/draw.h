#ifndef DRAW_H
#define DRAW_H

void DrawSetLocation(int x, int y);

#endif 
