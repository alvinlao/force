#include "draw.h"

void DrawSetLocation(int x, int y) {
    
}
